# ToDo4ToDay by RTNA — version 1.1

- Interface marron et jaune avec icône de marque.
- Gestion des tâches et sauvegarde locale.
- Chronomètre basé sur des horodatages.
- À la fin de la durée prévue : terminer ou continuer. Continuer ajoute 5 minutes à la durée prévue et reprend le chronomètre sans remise à zéro.
- Rappel quotidien à une heure choisie (format HH:MM), avec notifications locales Android.
- Fonctionne hors connexion après installation.

## Build Android
Le workflow GitHub Actions doit :
1. Décompresser `source.zip`.
2. Exécuter `flutter create . --platforms=android`.
3. Exécuter `flutter pub get`.
4. Exécuter `dart run flutter_launcher_icons`.
5. Exécuter `flutter build apk --release`.
6. Renommer le résultat en `ToDo4ToDay.apk`.
