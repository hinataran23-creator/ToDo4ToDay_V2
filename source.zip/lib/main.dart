import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

final FlutterLocalNotificationsPlugin notifications = FlutterLocalNotificationsPlugin();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  tzdata.initializeTimeZones();
  // Madagascar uses the Africa/Antananarivo time zone.
  tz.setLocalLocation(tz.getLocation('Africa/Antananarivo'));
  const init = InitializationSettings(
    android: AndroidInitializationSettings('@mipmap/ic_launcher'),
  );
  await notifications.initialize(init);
  await notifications
      .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
      ?.requestNotificationsPermission();
  runApp(const ToDo4ToDayApp());
}

const brown = Color(0xFF5D4037);
const darkBrown = Color(0xFF3E2723);
const yellow = Color(0xFFFFC857);
const cream = Color(0xFFFFF8E8);

class TaskItem {
  TaskItem({
    required this.id,
    required this.title,
    this.description = '',
    required this.targetMinutes,
    this.completed = false,
    this.startedAt,
    this.elapsedBeforeStart = 0,
    this.actualSeconds = 0,
    this.reminderTime,
  });

  final String id;
  String title;
  String description;
  int targetMinutes;
  bool completed;
  DateTime? startedAt;
  int elapsedBeforeStart;
  int actualSeconds;
  String? reminderTime;

  int elapsedNow() => elapsedBeforeStart +
      (startedAt == null ? 0 : DateTime.now().difference(startedAt!).inSeconds);

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'targetMinutes': targetMinutes,
        'completed': completed,
        'startedAt': startedAt?.toIso8601String(),
        'elapsedBeforeStart': elapsedBeforeStart,
        'actualSeconds': actualSeconds,
        'reminderTime': reminderTime,
      };

  factory TaskItem.fromJson(Map<String, dynamic> j) => TaskItem(
        id: j['id'],
        title: j['title'],
        description: j['description'] ?? '',
        targetMinutes: j['targetMinutes'] ?? 30,
        completed: j['completed'] ?? false,
        startedAt: j['startedAt'] == null ? null : DateTime.tryParse(j['startedAt']),
        elapsedBeforeStart: j['elapsedBeforeStart'] ?? 0,
        actualSeconds: j['actualSeconds'] ?? 0,
        reminderTime: j['reminderTime'],
      );
}

int notificationId(TaskItem task) {
  final raw = int.tryParse(task.id) ?? task.id.hashCode.abs();
  return raw.abs() % 2147483647;
}

Future<void> scheduleDailyReminder(TaskItem task) async {
  final id = notificationId(task);
  await notifications.cancel(id);
  if (task.reminderTime == null || task.reminderTime!.isEmpty) return;
  final parts = task.reminderTime!.split(':');
  if (parts.length != 2) return;
  final hour = int.tryParse(parts[0]);
  final minute = int.tryParse(parts[1]);
  if (hour == null || minute == null || hour < 0 || hour > 23 || minute < 0 || minute > 59) return;

  final now = tz.TZDateTime.now(tz.local);
  var first = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
  if (!first.isAfter(now)) first = first.add(const Duration(days: 1));

  await notifications.zonedSchedule(
    id,
    'Rappel : ${task.title}',
    task.description.isEmpty ? 'C’est le moment de réaliser ta tâche.' : task.description,
    first,
    const NotificationDetails(
      android: AndroidNotificationDetails(
        'daily_task_reminders',
        'Rappels quotidiens',
        channelDescription: 'Rappels quotidiens pour les tâches ToDo4ToDay',
        importance: Importance.high,
        priority: Priority.high,
      ),
    ),
    androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
    matchDateTimeComponents: DateTimeComponents.time,
  );
}

class ToDo4ToDayApp extends StatelessWidget {
  const ToDo4ToDayApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'ToDo4ToDay by RTNA',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: cream,
          colorScheme: ColorScheme.fromSeed(seedColor: brown, primary: brown, secondary: yellow),
          appBarTheme: const AppBarTheme(backgroundColor: brown, foregroundColor: Colors.white),
          floatingActionButtonTheme: const FloatingActionButtonThemeData(backgroundColor: yellow, foregroundColor: darkBrown),
        ),
        home: const HomePage(),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  final List<TaskItem> tasks = [];
  Timer? ticker;
  int tab = 0;
  bool loading = true;
  // Prevent the same task from opening the expiry dialog more than once.
  final Set<String> _targetDialogs = <String>{};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    loadTasks();
    ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
      _checkTargets();
    });
  }

  @override
  void dispose() {
    ticker?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> loadTasks() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('tasks');
    if (raw != null) {
      try {
        tasks.addAll((jsonDecode(raw) as List).map((e) => TaskItem.fromJson(e)));
        for (final task in tasks) {
          if (!task.completed) await scheduleDailyReminder(task);
        }
      } catch (_) {}
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> saveTasks() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('tasks', jsonEncode(tasks.map((e) => e.toJson()).toList()));
  }

  void _checkTargets() {
    for (final t in tasks) {
      if (t.startedAt != null &&
          t.elapsedNow() >= t.targetMinutes * 60 &&
          !_targetDialogs.contains(t.id)) {
        // Lock this task immediately, before scheduling the dialog. This stops
        // repeated timer ticks from queuing duplicate dialogs and adding +10 min.
        _targetDialogs.add(t.id);
        t.elapsedBeforeStart = t.elapsedNow();
        t.startedAt = null;
        saveTasks();
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _targetDialog(t);
        });
        break;
      }
    }
  }

  Future<void> _targetDialog(TaskItem t) async {
    try {
      if (!mounted || t.completed) return;
      final choice = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => AlertDialog(
          title: const Text('Durée prévue atteinte'),
          content: Text('La durée prévue pour « ${t.title} » est écoulée. As-tu terminé ?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Continuer (+5 min)'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Oui, terminé'),
            ),
          ],
        ),
      );
      if (!mounted) return;
      if (choice == true) {
        t.completed = true;
        t.actualSeconds = t.elapsedBeforeStart;
        await notifications.cancel(notificationId(t));
      } else if (choice == false) {
        // Exactly one increment per confirmation: add five minutes, then resume.
        t.targetMinutes += 5;
        t.startedAt = DateTime.now();
      }
      await saveTasks();
      if (mounted) setState(() {});
    } finally {
      _targetDialogs.remove(t.id);
    }
  }

  Future<void> addOrEdit({TaskItem? task}) async {
    final title = TextEditingController(text: task?.title ?? '');
    final desc = TextEditingController(text: task?.description ?? '');
    final mins = TextEditingController(text: '${task?.targetMinutes ?? 30}');
    final reminder = TextEditingController(text: task?.reminderTime ?? '');
    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(task == null ? 'Nouvelle tâche' : 'Modifier la tâche'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: title, autofocus: true, decoration: const InputDecoration(labelText: 'Nom de la tâche')),
          TextField(controller: desc, decoration: const InputDecoration(labelText: 'Description'), maxLines: 2),
          TextField(controller: mins, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Durée prévue (minutes)')),
          TextField(
            controller: reminder,
            keyboardType: TextInputType.datetime,
            decoration: const InputDecoration(
              labelText: 'Rappel quotidien (HH:MM)',
              hintText: 'Ex. 07:30 — laisser vide pour désactiver',
              helperText: 'Répété chaque jour à cette heure',
            ),
          ),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer')),
        ],
      ),
    );
    if (result != true || title.text.trim().isEmpty) return;
    final n = int.tryParse(mins.text.trim()) ?? 30;
    final r = reminder.text.trim();
    String? reminderValue;
    if (r.isNotEmpty && RegExp(r'^(?:[01]\d|2[0-3]):[0-5]\d$').hasMatch(r)) {
      reminderValue = r;
    } else if (r.isNotEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Heure invalide. Utilise le format HH:MM, par exemple 07:30.')),
        );
      }
      return;
    }

    TaskItem saved;
    if (task == null) {
      saved = TaskItem(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        title: title.text.trim(),
        description: desc.text.trim(),
        targetMinutes: n.clamp(1, 1440),
        reminderTime: reminderValue,
      );
      tasks.add(saved);
    } else {
      task.title = title.text.trim();
      task.description = desc.text.trim();
      task.targetMinutes = n.clamp(1, 1440);
      task.reminderTime = reminderValue;
      saved = task;
    }
    await scheduleDailyReminder(saved);
    await saveTasks();
    if (mounted) setState(() {});
  }

  Future<void> toggleTimer(TaskItem t) async {
    if (t.completed) return;
    if (t.startedAt == null) {
      t.startedAt = DateTime.now();
    } else {
      t.elapsedBeforeStart = t.elapsedNow();
      t.startedAt = null;
    }
    await saveTasks();
    setState(() {});
  }

  Future<void> finish(TaskItem t) async {
    t.actualSeconds = t.elapsedNow();
    t.elapsedBeforeStart = t.actualSeconds;
    t.startedAt = null;
    t.completed = true;
    await notifications.cancel(notificationId(t));
    await saveTasks();
    setState(() {});
  }

  Future<void> delete(TaskItem t) async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Supprimer cette tâche ?'),
      content: Text('« ${t.title} » sera supprimée.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Supprimer')),
      ],
    ));
    if (ok == true) {
      await notifications.cancel(notificationId(t));
      tasks.removeWhere((x) => x.id == t.id);
      await saveTasks();
      setState(() {});
    }
  }

  String duration(int s) {
    final h = s ~/ 3600, m = (s % 3600) ~/ 60, sec = s % 60;
    return h > 0 ? '${h}h ${m.toString().padLeft(2, '0')}m' : '${m}m ${sec.toString().padLeft(2, '0')}s';
  }

  @override
  Widget build(BuildContext context) {
    final done = tasks.where((t) => t.completed).length;
    final total = tasks.length;
    return Scaffold(
      appBar: AppBar(title: Row(children: [
        Image.asset('assets/app_icon.png', width: 38, height: 38),
        const SizedBox(width: 9),
        const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('ToDo4ToDay', style: TextStyle(fontWeight: FontWeight.bold)),
          Text('by RTNA', style: TextStyle(fontSize: 11, color: yellow)),
        ]),
      ]), actions: [IconButton(onPressed: () => showAboutDialog(context: context, applicationName: 'ToDo4ToDay by RTNA', applicationVersion: '1.1.0', children: const [Text('Ton assistant quotidien, utilisable hors connexion.')]), icon: const Icon(Icons.info_outline))]),
      body: loading ? const Center(child: CircularProgressIndicator()) : tab == 0 ? _dashboard(done, total) : _stats(done, total),
      floatingActionButton: tab == 0 ? FloatingActionButton.extended(onPressed: () => addOrEdit(), icon: const Icon(Icons.add), label: const Text('Ajouter')) : null,
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.checklist), label: 'Mes tâches'),
        NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Bilan'),
      ]),
    );
  }

  Widget _dashboard(int done, int total) {
    final active = tasks.where((t) => !t.completed).length;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: brown, borderRadius: BorderRadius.circular(20)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Aujourd’hui, avance à ton rythme.', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: _metric('$total', 'Tâches')),
          Expanded(child: _metric('$done', 'Terminées')),
          Expanded(child: _metric('${total == 0 ? 0 : (done * 100 / total).round()}%', 'Progression')),
        ]),
        const SizedBox(height: 10),
        ClipRRect(borderRadius: BorderRadius.circular(10), child: LinearProgressIndicator(value: total == 0 ? 0 : done / total, minHeight: 8, backgroundColor: Colors.white24, color: yellow)),
      ])),
      const SizedBox(height: 20),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Mes tâches', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: darkBrown)), Text('$active en cours', style: const TextStyle(color: brown))]),
      const SizedBox(height: 8),
      if (tasks.isEmpty) Container(padding: const EdgeInsets.all(28), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)), child: const Column(children: [Icon(Icons.event_note, size: 42, color: brown), SizedBox(height: 8), Text('Aucune tâche pour le moment'), Text('Appuie sur Ajouter pour commencer.', style: TextStyle(color: Colors.black54))]))
      else ...tasks.map(_taskCard),
    ]);
  }

  Widget _metric(String value, String label) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(value, style: const TextStyle(color: yellow, fontSize: 22, fontWeight: FontWeight.bold)), Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12))]);

  Widget _taskCard(TaskItem t) {
    final elapsed = t.completed ? t.actualSeconds : t.elapsedNow();
    final running = t.startedAt != null;
    return Card(color: Colors.white, margin: const EdgeInsets.only(bottom: 10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Expanded(child: Text(t.title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, decoration: t.completed ? TextDecoration.lineThrough : null, color: darkBrown))),
        PopupMenuButton<String>(onSelected: (v) { if (v == 'edit') addOrEdit(task: t); if (v == 'delete') delete(t); }, itemBuilder: (_) => const [PopupMenuItem(value: 'edit', child: Text('Modifier')), PopupMenuItem(value: 'delete', child: Text('Supprimer'))]),
      ]),
      if (t.description.isNotEmpty) Text(t.description, style: const TextStyle(color: Colors.black54)),
      const SizedBox(height: 8),
      Row(children: [const Icon(Icons.flag_outlined, size: 16, color: brown), const SizedBox(width: 4), Text('Prévu : ${t.targetMinutes} min'), const Spacer(), const Icon(Icons.timer_outlined, size: 16, color: brown), const SizedBox(width: 4), Text('Écoulé : ${duration(elapsed)}')]),
      if (t.reminderTime != null) Padding(padding: const EdgeInsets.only(top: 5), child: Row(children: [const Icon(Icons.notifications_active_outlined, size: 16, color: brown), const SizedBox(width: 4), Text('Rappel quotidien : ${t.reminderTime}') ])),
      const SizedBox(height: 10),
      if (!t.completed) Row(children: [
        Expanded(child: OutlinedButton.icon(onPressed: () => toggleTimer(t), icon: Icon(running ? Icons.pause : Icons.play_arrow), label: Text(running ? 'Pause' : 'Démarrer'))),
        const SizedBox(width: 8),
        Expanded(child: FilledButton.icon(onPressed: () => finish(t), icon: const Icon(Icons.check), label: const Text('Terminer'))),
      ]) else const Row(children: [Icon(Icons.check_circle, color: Colors.green), SizedBox(width: 6), Text('Terminée', style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold))]),
    ])));
  }

  Widget _stats(int done, int total) {
    final seconds = tasks.fold<int>(0, (sum, t) => sum + (t.completed ? t.actualSeconds : t.elapsedNow()));
    final planned = tasks.fold<int>(0, (sum, t) => sum + t.targetMinutes * 60);
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Mon bilan', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: darkBrown)),
      const SizedBox(height: 14),
      _statTile(Icons.task_alt, 'Tâches terminées', '$done / $total'),
      _statTile(Icons.timer, 'Temps réellement consacré', duration(seconds)),
      _statTile(Icons.flag, 'Temps prévu cumulé', duration(planned)),
      _statTile(Icons.insights, 'Progression', '${total == 0 ? 0 : (done * 100 / total).round()} %'),
      const SizedBox(height: 16),
      const Text('Comparaison du temps', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: darkBrown)),
      const SizedBox(height: 8),
      ...tasks.map((t) {
        final actual = t.completed ? t.actualSeconds : t.elapsedNow();
        final max = (t.targetMinutes * 60).clamp(1, 1000000000);
        return Padding(padding: const EdgeInsets.only(bottom: 12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(t.title, maxLines: 1, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 4),
          ClipRRect(borderRadius: BorderRadius.circular(8), child: LinearProgressIndicator(value: (actual / max).clamp(0.0, 1.0), minHeight: 9, color: actual > max ? Colors.deepOrange : brown, backgroundColor: Colors.brown.shade100)),
          Text('${duration(actual)} / ${t.targetMinutes} min prévues', style: const TextStyle(fontSize: 12, color: Colors.black54)),
        ]));
      }),
      const SizedBox(height: 10),
      const Text('Les données sont enregistrées sur cet appareil. Les rappels quotidiens sont programmés localement.', style: TextStyle(color: Colors.black54)),
    ]);
  }

  Widget _statTile(IconData icon, String label, String value) => Card(color: Colors.white, child: ListTile(leading: Icon(icon, color: brown), title: Text(label), trailing: Text(value, style: const TextStyle(fontWeight: FontWeight.bold, color: darkBrown))));
}
